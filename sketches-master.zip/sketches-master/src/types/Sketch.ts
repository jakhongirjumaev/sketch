export interface Sketch {
  id: string;
  title: string;
  author: string;
  thumbnailURL: string;
  component: React.ComponentType;
}
